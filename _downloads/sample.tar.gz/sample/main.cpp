#include <iostream>
#include <vector>
#include <algorithm>

int main()
{
	
	return 0;
}
